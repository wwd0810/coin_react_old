export { default } from "./CenterTerm";
