export { default } from "./CenterInquiry";
