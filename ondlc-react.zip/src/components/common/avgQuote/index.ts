export { default } from "./AvgQuote";
