export { default } from "./BuyingHistory";
