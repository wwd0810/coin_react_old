import React from "react";
import Loading from "components/common/loading/Loading";

function Callback() {
  return <Loading />;
}

export default Callback;
