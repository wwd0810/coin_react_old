export { default } from "./DlcInfoItem";
