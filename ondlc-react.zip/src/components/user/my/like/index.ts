export { default } from "./MyLike";
