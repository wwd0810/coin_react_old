export { default } from "./stackTemplate";
