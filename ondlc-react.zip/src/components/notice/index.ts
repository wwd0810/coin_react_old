export { default } from "./Notice";
