import React from "react";
import CallbackContainer from "containers/user/callback/CallbackContainer";

function CallbackPage() {
  return <CallbackContainer />;
}

export default CallbackPage;
