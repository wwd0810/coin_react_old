export { default } from "./DlcInfo";
