export { default } from "./BuyingDetail";
