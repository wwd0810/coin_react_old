export { default } from "./BuyingManage";
