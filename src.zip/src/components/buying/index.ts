export { default } from "./Buying";
