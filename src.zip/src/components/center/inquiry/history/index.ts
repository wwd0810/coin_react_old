export { default } from "./InquiryHistory";
