export { default } from "./InquiryApply";
