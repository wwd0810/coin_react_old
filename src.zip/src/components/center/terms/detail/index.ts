export { default } from "./TermDetail";
