export { default } from "./CenterNotice";
