export { default } from "./CenterQuestion";
